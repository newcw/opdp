
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */


#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>

#define PT_RAND_RANGE 1000
#define PT_REQID_LENGTH 11

static ngx_int_t ngx_http_reqid_handler(ngx_http_request_t *r);
static ngx_int_t ngx_http_reqid_init(ngx_conf_t *cf);


ngx_http_module_t  ngx_http_reqid_module_ctx = {
    NULL,                                  /* preconfiguration */
    ngx_http_reqid_init,                  /* postconfiguration */

    NULL,                                  /* create main configuration */
    NULL,                                  /* init main configuration */

    NULL,                                  /* create server configuration */
    NULL,                                  /* merge server configuration */

    NULL,                                  /* create location configuration */
    NULL                                   /* merge location configuration */
};


ngx_module_t  ngx_http_reqid_module = {
    NGX_MODULE_V1,
    &ngx_http_reqid_module_ctx,           /* module context */
    NULL,                                  /* module directives */
    NGX_HTTP_MODULE,                       /* module type */
    NULL,                                  /* init master */
    NULL,                                  /* init module */
    NULL,                                  /* init process */
    NULL,                                  /* init thread */
    NULL,                                  /* exit thread */
    NULL,                                  /* exit process */
    NULL,                                  /* exit master */
    NGX_MODULE_V1_PADDING
};


static ngx_int_t
ngx_http_reqid_handler(ngx_http_request_t *r)
{
    ngx_time_t *tp;
    tp = ngx_timeofday();

    ngx_table_elt_t *h;
    ngx_str_t name = ngx_string("reqid");

    h = ngx_list_push(&r->headers_in.headers);
    if(h == NULL){
        return NGX_ERROR;
    }
    h->hash = 1;
    h->key.len = name.len;
    h->key.data = name.data;

    // reqid
    struct timeval tv = {0, 0};
    char *reqid = NULL;
    ngx_uint_t reqid_real_len = 0;
    ngx_int_t random_number = 0;
    reqid = (char *) ngx_pcalloc(r->connection->pool, PT_REQID_LENGTH);
    if(reqid == NULL) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "reqid alloc failed ");
        return NGX_DECLINED;
    }
    ngx_gettimeofday(&tv);

    random_number = ngx_random() / (RAND_MAX + 1.0) * PT_RAND_RANGE;
    ngx_snprintf((u_char *)reqid, PT_REQID_LENGTH, "%04d%03d%03d", tv.tv_sec%3600, tv.tv_usec/1000, random_number);

    reqid_real_len = strlen((char *)reqid);
    if(reqid_real_len >= PT_REQID_LENGTH) {
        return NGX_DECLINED;
    }

    h->value.len = reqid_real_len;
    h->value.data = (u_char *)reqid;

    return NGX_DECLINED;
}


static ngx_int_t
ngx_http_reqid_init(ngx_conf_t *cf)
{
    ngx_http_handler_pt        *h;
    ngx_http_core_main_conf_t  *cmcf;

    cmcf = ngx_http_conf_get_module_main_conf(cf, ngx_http_core_module);

    h = ngx_array_push(&cmcf->phases[NGX_HTTP_SERVER_REWRITE_PHASE].handlers);
    if (h == NULL) {
        return NGX_ERROR;
    }

    *h = ngx_http_reqid_handler;

    return NGX_OK;
}
